import { createBrowserRouter } from "react-router";
import Home from "./components/Home";
import Login from "./components/Login";
import Register from "./components/Register";
import Admin from "./components/Admin";
import History from "./components/History";
import SecureAccess from "./components/SecureAccess";
import AccessHistory from "./components/AccessHistory";
import AdminControl from "./components/AdminControl";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/register",
    Component: Register,
  },
  {
    path: "/admin",
    Component: Admin,
  },
  {
    path: "/history",
    Component: History,
  },
  {
    path: "/secure-access",
    Component: SecureAccess,
  },
  {
    path: "/access-history",
    Component: AccessHistory,
  },
  {
    path: "/admin-control",
    Component: AdminControl,
  },
]);
