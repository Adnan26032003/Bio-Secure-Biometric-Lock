import { useState } from 'react';
import { Link } from 'react-router';
import { Shield, History as HistoryIcon, CheckCircle, XCircle, Filter, Download, ArrowLeft, Calendar, Search, TrendingUp, TrendingDown } from 'lucide-react';

export default function AccessHistory() {
  const [filterStatus, setFilterStatus] = useState<'all' | 'success' | 'failed'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState('today');

  const accessLogs = [
    {
      id: 1,
      timestamp: '2024-05-20 16:45:23',
      user: 'John Doe',
      userId: 'EMP001',
      location: 'Main Entrance - Door A',
      status: 'success',
      method: 'Biometric',
      duration: '2s',
      ipAddress: '192.168.1.100',
    },
    {
      id: 2,
      timestamp: '2024-05-20 16:30:15',
      user: 'Jane Smith',
      userId: 'EMP002',
      location: 'Conference Room - Door B',
      status: 'success',
      method: 'Biometric',
      duration: '1s',
      ipAddress: '192.168.1.101',
    },
    {
      id: 3,
      timestamp: '2024-05-20 16:15:42',
      user: 'Unknown User',
      userId: 'N/A',
      location: 'Server Room - Door C',
      status: 'failed',
      method: 'Biometric',
      duration: '3s',
      ipAddress: '192.168.1.255',
    },
    {
      id: 4,
      timestamp: '2024-05-20 15:55:30',
      user: 'Alice Williams',
      userId: 'EMP003',
      location: 'Main Entrance - Door A',
      status: 'success',
      method: 'Password',
      duration: '4s',
      ipAddress: '192.168.1.102',
    },
    {
      id: 5,
      timestamp: '2024-05-20 15:40:12',
      user: 'Bob Johnson',
      userId: 'EMP004',
      location: 'Storage - Door D',
      status: 'success',
      method: 'Biometric',
      duration: '2s',
      ipAddress: '192.168.1.103',
    },
    {
      id: 6,
      timestamp: '2024-05-20 15:20:45',
      user: 'Unknown User',
      userId: 'N/A',
      location: 'Main Entrance - Door A',
      status: 'failed',
      method: 'Biometric',
      duration: '5s',
      ipAddress: '192.168.1.255',
    },
    {
      id: 7,
      timestamp: '2024-05-20 14:55:18',
      user: 'John Doe',
      userId: 'EMP001',
      location: 'Lab - Door E',
      status: 'success',
      method: 'Biometric',
      duration: '1s',
      ipAddress: '192.168.1.100',
    },
    {
      id: 8,
      timestamp: '2024-05-20 14:30:33',
      user: 'Jane Smith',
      userId: 'EMP002',
      location: 'Main Entrance - Door A',
      status: 'success',
      method: 'Biometric',
      duration: '2s',
      ipAddress: '192.168.1.101',
    },
    {
      id: 9,
      timestamp: '2024-05-20 14:10:21',
      user: 'Unknown User',
      userId: 'N/A',
      location: 'Conference Room - Door B',
      status: 'failed',
      method: 'Password',
      duration: '6s',
      ipAddress: '192.168.1.255',
    },
    {
      id: 10,
      timestamp: '2024-05-20 13:45:55',
      user: 'Alice Williams',
      userId: 'EMP003',
      location: 'Main Entrance - Door A',
      status: 'success',
      method: 'Biometric',
      duration: '2s',
      ipAddress: '192.168.1.102',
    },
  ];

  const filteredLogs = accessLogs.filter((log) => {
    const statusMatch = filterStatus === 'all' || log.status === filterStatus;
    const searchMatch =
      searchQuery === '' ||
      log.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.userId.toLowerCase().includes(searchQuery.toLowerCase());
    return statusMatch && searchMatch;
  });

  const successCount = accessLogs.filter((log) => log.status === 'success').length;
  const failedCount = accessLogs.filter((log) => log.status === 'failed').length;
  const successRate = ((successCount / accessLogs.length) * 100).toFixed(1);
  const biometricCount = accessLogs.filter((log) => log.method === 'Biometric').length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900">
      <nav className="bg-black/20 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Shield className="w-8 h-8 text-blue-300" />
              <span className="text-2xl font-bold text-white">Access History</span>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/secure-access" className="px-4 py-2 text-white hover:text-blue-300 transition-colors">
                Secure Access
              </Link>
              <Link to="/admin-control" className="px-4 py-2 text-white hover:text-blue-300 transition-colors">
                Admin Control
              </Link>
              <Link to="/admin" className="px-4 py-2 text-white hover:text-blue-300 transition-colors flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Dashboard
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-2">
            <HistoryIcon className="w-8 h-8" />
            Access History & Analytics
          </h1>
          <p className="text-blue-200">Comprehensive log and analysis of all access attempts</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between mb-2">
              <div className="text-3xl font-bold text-white">{accessLogs.length}</div>
              <HistoryIcon className="w-8 h-8 text-blue-300" />
            </div>
            <div className="text-blue-200 text-sm mb-2">Total Attempts</div>
            <div className="flex items-center gap-1 text-green-300 text-xs">
              <TrendingUp className="w-3 h-3" />
              <span>+12% from yesterday</span>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between mb-2">
              <div className="text-3xl font-bold text-green-300">{successCount}</div>
              <CheckCircle className="w-8 h-8 text-green-300" />
            </div>
            <div className="text-blue-200 text-sm mb-2">Successful Access</div>
            <div className="flex items-center gap-1 text-green-300 text-xs">
              <TrendingUp className="w-3 h-3" />
              <span>{successRate}% success rate</span>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between mb-2">
              <div className="text-3xl font-bold text-red-300">{failedCount}</div>
              <XCircle className="w-8 h-8 text-red-300" />
            </div>
            <div className="text-blue-200 text-sm mb-2">Failed Attempts</div>
            <div className="flex items-center gap-1 text-red-300 text-xs">
              <TrendingDown className="w-3 h-3" />
              <span>-5% from yesterday</span>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between mb-2">
              <div className="text-3xl font-bold text-purple-300">{biometricCount}</div>
              <Shield className="w-8 h-8 text-purple-300" />
            </div>
            <div className="text-blue-200 text-sm mb-2">Biometric Auth</div>
            <div className="flex items-center gap-1 text-purple-300 text-xs">
              <TrendingUp className="w-3 h-3" />
              <span>{((biometricCount / accessLogs.length) * 100).toFixed(0)}% of total</span>
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 overflow-hidden">
          <div className="p-6 border-b border-white/20">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <h2 className="text-xl font-semibold text-white">Detailed Access Logs</h2>
              <div className="flex flex-wrap gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-300" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search user or location..."
                    className="pl-10 pr-4 py-2 bg-white/5 border border-white/20 rounded-lg text-white placeholder-blue-300/50 focus:outline-none focus:border-blue-400"
                  />
                </div>
                <div className="flex items-center gap-2 bg-white/5 rounded-lg px-4 py-2 border border-white/20">
                  <Calendar className="w-4 h-4 text-blue-300" />
                  <select
                    value={dateFilter}
                    onChange={(e) => setDateFilter(e.target.value)}
                    className="bg-transparent text-white border-none outline-none cursor-pointer"
                  >
                    <option value="today">Today</option>
                    <option value="week">This Week</option>
                    <option value="month">This Month</option>
                    <option value="all">All Time</option>
                  </select>
                </div>
                <div className="flex items-center gap-2 bg-white/5 rounded-lg px-4 py-2 border border-white/20">
                  <Filter className="w-4 h-4 text-blue-300" />
                  <select
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value as 'all' | 'success' | 'failed')}
                    className="bg-transparent text-white border-none outline-none cursor-pointer"
                  >
                    <option value="all">All Status</option>
                    <option value="success">Success Only</option>
                    <option value="failed">Failed Only</option>
                  </select>
                </div>
                <button className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                  <Download className="w-4 h-4" />
                  Export CSV
                </button>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-white/5">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    Timestamp
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    User ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    Location
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    Method
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    Duration
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-blue-200 text-sm">
                      {log.timestamp}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-white font-medium">
                      {log.user}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-blue-200 text-sm">
                      {log.userId}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-blue-200">
                      {log.location}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-blue-200">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold ${
                        log.method === 'Biometric' ? 'bg-purple-500/20 text-purple-300' : 'bg-blue-500/20 text-blue-300'
                      }`}>
                        {log.method}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-blue-200 text-sm">
                      {log.duration}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {log.status === 'success' ? (
                        <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-green-500/20 text-green-300">
                          <CheckCircle className="w-3 h-3" />
                          Success
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-red-500/20 text-red-300">
                          <XCircle className="w-3 h-3" />
                          Failed
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredLogs.length === 0 && (
            <div className="text-center py-12 text-blue-200">
              No access logs found matching your filters.
            </div>
          )}

          <div className="p-4 border-t border-white/20 text-sm text-blue-200">
            Showing {filteredLogs.length} of {accessLogs.length} total entries
          </div>
        </div>
      </div>
    </div>
  );
}
