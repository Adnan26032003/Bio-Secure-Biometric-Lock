import { Link } from 'react-router';
import { Shield, Users, History, Settings, Lock, Unlock, UserCheck, UserX, LogOut } from 'lucide-react';

export default function Admin() {
  const users = [
    { id: 1, name: 'John Doe', email: 'john@example.com', status: 'active', lastAccess: '2024-05-20 14:32' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com', status: 'active', lastAccess: '2024-05-20 12:15' },
    { id: 3, name: 'Bob Johnson', email: 'bob@example.com', status: 'inactive', lastAccess: '2024-05-19 09:45' },
    { id: 4, name: 'Alice Williams', email: 'alice@example.com', status: 'active', lastAccess: '2024-05-20 16:20' },
  ];

  const stats = [
    { label: 'Total Users', value: '24', icon: Users, color: 'blue' },
    { label: 'Active Today', value: '12', icon: UserCheck, color: 'green' },
    { label: 'Access Attempts', value: '156', icon: Lock, color: 'purple' },
    { label: 'Failed Attempts', value: '3', icon: UserX, color: 'red' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900">
      <nav className="bg-black/20 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Shield className="w-8 h-8 text-blue-300" />
              <span className="text-2xl font-bold text-white">BioSecure Admin</span>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/history" className="px-4 py-2 text-white hover:text-blue-300 transition-colors flex items-center gap-2">
                <History className="w-4 h-4" />
                History
              </Link>
              <Link to="/" className="px-4 py-2 text-white hover:text-blue-300 transition-colors flex items-center gap-2">
                <LogOut className="w-4 h-4" />
                Logout
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Admin Dashboard</h1>
          <p className="text-blue-200">Manage users and monitor system activity</p>
        </div>

        <div className="grid md:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-lg bg-${stat.color}-500/20`}>
                    <Icon className={`w-6 h-6 text-${stat.color}-300`} />
                  </div>
                </div>
                <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-blue-200 text-sm">{stat.label}</div>
              </div>
            );
          })}
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 overflow-hidden">
          <div className="p-6 border-b border-white/20">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-white flex items-center gap-2">
                <Users className="w-5 h-5" />
                User Management
              </h2>
              <button className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                Add New User
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-white/5">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    Email
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    Last Access
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {users.map((user) => (
                  <tr key={user.id} className="hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-white font-medium">
                      {user.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-blue-200">
                      {user.email}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${
                          user.status === 'active'
                            ? 'bg-green-500/20 text-green-300'
                            : 'bg-red-500/20 text-red-300'
                        }`}
                      >
                        {user.status === 'active' ? (
                          <Unlock className="w-3 h-3" />
                        ) : (
                          <Lock className="w-3 h-3" />
                        )}
                        {user.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-blue-200">
                      {user.lastAccess}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex gap-2">
                        <button className="p-2 text-blue-300 hover:bg-blue-500/20 rounded-lg transition-colors">
                          <Settings className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-red-300 hover:bg-red-500/20 rounded-lg transition-colors">
                          <UserX className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-8 grid md:grid-cols-2 gap-6">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Recent Access Attempts
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-white">John Doe - Door A</span>
                <span className="text-green-300">Success</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-white">Jane Smith - Door B</span>
                <span className="text-green-300">Success</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-white">Unknown - Door A</span>
                <span className="text-red-300">Failed</span>
              </div>
            </div>
            <Link to="/history" className="mt-4 block text-center text-blue-300 hover:text-blue-200 text-sm">
              View Full History →
            </Link>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Quick Settings
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-white">Lock All Doors</span>
                <button className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors text-sm">
                  Lock All
                </button>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white">Emergency Override</span>
                <button className="px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 transition-colors text-sm">
                  Override
                </button>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white">System Status</span>
                <span className="text-green-300">● Online</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
