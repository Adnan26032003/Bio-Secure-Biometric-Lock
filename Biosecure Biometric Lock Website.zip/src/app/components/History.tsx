import { useState } from 'react';
import { Link } from 'react-router';
import { Shield, History as HistoryIcon, CheckCircle, XCircle, Filter, Download, ArrowLeft } from 'lucide-react';

export default function History() {
  const [filterStatus, setFilterStatus] = useState<'all' | 'success' | 'failed'>('all');

  const accessLogs = [
    {
      id: 1,
      timestamp: '2024-05-20 16:45:23',
      user: 'John Doe',
      location: 'Main Entrance - Door A',
      status: 'success',
      method: 'Biometric',
    },
    {
      id: 2,
      timestamp: '2024-05-20 16:30:15',
      user: 'Jane Smith',
      location: 'Conference Room - Door B',
      status: 'success',
      method: 'Biometric',
    },
    {
      id: 3,
      timestamp: '2024-05-20 16:15:42',
      user: 'Unknown User',
      location: 'Server Room - Door C',
      status: 'failed',
      method: 'Biometric',
    },
    {
      id: 4,
      timestamp: '2024-05-20 15:55:30',
      user: 'Alice Williams',
      location: 'Main Entrance - Door A',
      status: 'success',
      method: 'Password',
    },
    {
      id: 5,
      timestamp: '2024-05-20 15:40:12',
      user: 'Bob Johnson',
      location: 'Storage - Door D',
      status: 'success',
      method: 'Biometric',
    },
    {
      id: 6,
      timestamp: '2024-05-20 15:20:45',
      user: 'Unknown User',
      location: 'Main Entrance - Door A',
      status: 'failed',
      method: 'Biometric',
    },
    {
      id: 7,
      timestamp: '2024-05-20 14:55:18',
      user: 'John Doe',
      location: 'Lab - Door E',
      status: 'success',
      method: 'Biometric',
    },
    {
      id: 8,
      timestamp: '2024-05-20 14:30:33',
      user: 'Jane Smith',
      location: 'Main Entrance - Door A',
      status: 'success',
      method: 'Biometric',
    },
    {
      id: 9,
      timestamp: '2024-05-20 14:10:21',
      user: 'Unknown User',
      location: 'Conference Room - Door B',
      status: 'failed',
      method: 'Password',
    },
    {
      id: 10,
      timestamp: '2024-05-20 13:45:55',
      user: 'Alice Williams',
      location: 'Main Entrance - Door A',
      status: 'success',
      method: 'Biometric',
    },
  ];

  const filteredLogs = accessLogs.filter((log) => {
    if (filterStatus === 'all') return true;
    return log.status === filterStatus;
  });

  const successCount = accessLogs.filter((log) => log.status === 'success').length;
  const failedCount = accessLogs.filter((log) => log.status === 'failed').length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900">
      <nav className="bg-black/20 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Shield className="w-8 h-8 text-blue-300" />
              <span className="text-2xl font-bold text-white">BioSecure History</span>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/admin" className="px-4 py-2 text-white hover:text-blue-300 transition-colors flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back to Admin
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-2">
            <HistoryIcon className="w-8 h-8" />
            Access History
          </h1>
          <p className="text-blue-200">Complete log of all access attempts</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="text-3xl font-bold text-white mb-1">{accessLogs.length}</div>
            <div className="text-blue-200">Total Attempts</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="text-3xl font-bold text-green-300 mb-1">{successCount}</div>
            <div className="text-blue-200">Successful Access</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="text-3xl font-bold text-red-300 mb-1">{failedCount}</div>
            <div className="text-blue-200">Failed Attempts</div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 overflow-hidden">
          <div className="p-6 border-b border-white/20">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <h2 className="text-xl font-semibold text-white">Access Logs</h2>
              <div className="flex gap-3">
                <div className="flex items-center gap-2 bg-white/5 rounded-lg px-4 py-2">
                  <Filter className="w-4 h-4 text-blue-300" />
                  <select
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value as 'all' | 'success' | 'failed')}
                    className="bg-transparent text-white border-none outline-none cursor-pointer"
                  >
                    <option value="all">All Status</option>
                    <option value="success">Success Only</option>
                    <option value="failed">Failed Only</option>
                  </select>
                </div>
                <button className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                  <Download className="w-4 h-4" />
                  Export
                </button>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-white/5">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    Timestamp
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    Location
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    Method
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-blue-200 text-sm">
                      {log.timestamp}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-white font-medium">
                      {log.user}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-blue-200">
                      {log.location}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-blue-200">
                      {log.method}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {log.status === 'success' ? (
                        <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-green-500/20 text-green-300">
                          <CheckCircle className="w-3 h-3" />
                          Success
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-red-500/20 text-red-300">
                          <XCircle className="w-3 h-3" />
                          Failed
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredLogs.length === 0 && (
            <div className="text-center py-12 text-blue-200">
              No access logs found for the selected filter.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
