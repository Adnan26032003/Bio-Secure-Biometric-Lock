import { useState } from 'react';
import { Link } from 'react-router';
import { Shield, Settings, Bell, Lock, Database, Wifi, Server, AlertTriangle, Users, Key, FileText, Activity, ArrowLeft, Save, RotateCcw } from 'lucide-react';

export default function AdminControl() {
  const [settings, setSettings] = useState({
    autoLockEnabled: true,
    autoLockDelay: 30,
    biometricOnly: false,
    twoFactorAuth: true,
    notificationsEnabled: true,
    emailAlerts: true,
    smsAlerts: false,
    auditLogging: true,
    sessionTimeout: 60,
    maxLoginAttempts: 3,
    passwordExpiry: 90,
  });

  const [systemStatus, setSystemStatus] = useState({
    database: 'online',
    biometricScanner: 'online',
    networkConnection: 'online',
    backupServer: 'online',
    apiService: 'online',
  });

  const handleSettingChange = (key: string, value: boolean | number) => {
    setSettings({ ...settings, [key]: value });
  };

  const saveSettings = () => {
    alert('Settings saved successfully!');
  };

  const resetToDefaults = () => {
    if (confirm('Are you sure you want to reset all settings to default values?')) {
      setSettings({
        autoLockEnabled: true,
        autoLockDelay: 30,
        biometricOnly: false,
        twoFactorAuth: true,
        notificationsEnabled: true,
        emailAlerts: true,
        smsAlerts: false,
        auditLogging: true,
        sessionTimeout: 60,
        maxLoginAttempts: 3,
        passwordExpiry: 90,
      });
      alert('Settings reset to defaults!');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900">
      <nav className="bg-black/20 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Shield className="w-8 h-8 text-blue-300" />
              <span className="text-2xl font-bold text-white">Admin Control Panel</span>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/secure-access" className="px-4 py-2 text-white hover:text-blue-300 transition-colors">
                Secure Access
              </Link>
              <Link to="/access-history" className="px-4 py-2 text-white hover:text-blue-300 transition-colors">
                History
              </Link>
              <Link to="/admin" className="px-4 py-2 text-white hover:text-blue-300 transition-colors flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Dashboard
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-2">
              <Settings className="w-8 h-8" />
              System Configuration & Control
            </h1>
            <p className="text-blue-200">Manage system settings, security, and monitoring</p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={resetToDefaults}
              className="flex items-center gap-2 px-6 py-3 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors font-semibold border border-white/20"
            >
              <RotateCcw className="w-5 h-5" />
              Reset to Defaults
            </button>
            <button
              onClick={saveSettings}
              className="flex items-center gap-2 px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-semibold"
            >
              <Save className="w-5 h-5" />
              Save Changes
            </button>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 p-6">
            <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Security Settings
            </h2>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-white font-medium">Auto-Lock Doors</div>
                  <div className="text-blue-200 text-sm">Automatically lock doors after access</div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.autoLockEnabled}
                    onChange={(e) => handleSettingChange('autoLockEnabled', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                </label>
              </div>

              {settings.autoLockEnabled && (
                <div>
                  <label className="text-white font-medium block mb-2">Auto-Lock Delay (seconds)</label>
                  <input
                    type="number"
                    value={settings.autoLockDelay}
                    onChange={(e) => handleSettingChange('autoLockDelay', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/5 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
                  />
                </div>
              )}

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-white font-medium">Biometric-Only Mode</div>
                  <div className="text-blue-200 text-sm">Disable password authentication</div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.biometricOnly}
                    onChange={(e) => handleSettingChange('biometricOnly', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                </label>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-white font-medium">Two-Factor Authentication</div>
                  <div className="text-blue-200 text-sm">Require 2FA for admin access</div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.twoFactorAuth}
                    onChange={(e) => handleSettingChange('twoFactorAuth', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                </label>
              </div>

              <div>
                <label className="text-white font-medium block mb-2">Session Timeout (minutes)</label>
                <input
                  type="number"
                  value={settings.sessionTimeout}
                  onChange={(e) => handleSettingChange('sessionTimeout', parseInt(e.target.value))}
                  className="w-full px-4 py-2 bg-white/5 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
                />
              </div>

              <div>
                <label className="text-white font-medium block mb-2">Max Login Attempts</label>
                <input
                  type="number"
                  value={settings.maxLoginAttempts}
                  onChange={(e) => handleSettingChange('maxLoginAttempts', parseInt(e.target.value))}
                  className="w-full px-4 py-2 bg-white/5 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
                />
              </div>

              <div>
                <label className="text-white font-medium block mb-2">Password Expiry (days)</label>
                <input
                  type="number"
                  value={settings.passwordExpiry}
                  onChange={(e) => handleSettingChange('passwordExpiry', parseInt(e.target.value))}
                  className="w-full px-4 py-2 bg-white/5 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
                />
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 p-6">
              <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Notification Settings
              </h2>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-white font-medium">Enable Notifications</div>
                    <div className="text-blue-200 text-sm">Receive system notifications</div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.notificationsEnabled}
                      onChange={(e) => handleSettingChange('notificationsEnabled', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                  </label>
                </div>

                {settings.notificationsEnabled && (
                  <>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-white font-medium">Email Alerts</div>
                        <div className="text-blue-200 text-sm">Security alerts via email</div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.emailAlerts}
                          onChange={(e) => handleSettingChange('emailAlerts', e.target.checked)}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                      </label>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-white font-medium">SMS Alerts</div>
                        <div className="text-blue-200 text-sm">Critical alerts via SMS</div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.smsAlerts}
                          onChange={(e) => handleSettingChange('smsAlerts', e.target.checked)}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                      </label>
                    </div>
                  </>
                )}

                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-white font-medium">Audit Logging</div>
                    <div className="text-blue-200 text-sm">Log all system activities</div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.auditLogging}
                      onChange={(e) => handleSettingChange('auditLogging', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                  </label>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 p-6">
              <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
                <Activity className="w-5 h-5" />
                System Status
              </h2>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Database className="w-5 h-5 text-blue-300" />
                    <span className="text-white">Database Server</span>
                  </div>
                  <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-green-500/20 text-green-300">
                    ● {systemStatus.database}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Key className="w-5 h-5 text-blue-300" />
                    <span className="text-white">Biometric Scanner</span>
                  </div>
                  <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-green-500/20 text-green-300">
                    ● {systemStatus.biometricScanner}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Wifi className="w-5 h-5 text-blue-300" />
                    <span className="text-white">Network Connection</span>
                  </div>
                  <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-green-500/20 text-green-300">
                    ● {systemStatus.networkConnection}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Server className="w-5 h-5 text-blue-300" />
                    <span className="text-white">Backup Server</span>
                  </div>
                  <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-green-500/20 text-green-300">
                    ● {systemStatus.backupServer}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Activity className="w-5 h-5 text-blue-300" />
                    <span className="text-white">API Service</span>
                  </div>
                  <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-green-500/20 text-green-300">
                    ● {systemStatus.apiService}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Users className="w-5 h-5" />
              User Management
            </h3>
            <div className="space-y-3">
              <Link to="/admin" className="block px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-center">
                Manage Users
              </Link>
              <button className="w-full px-4 py-2 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors border border-white/20">
                User Permissions
              </button>
              <button className="w-full px-4 py-2 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors border border-white/20">
                Role Management
              </button>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5" />
              System Logs
            </h3>
            <div className="space-y-3">
              <Link to="/access-history" className="block px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-center">
                View Access Logs
              </Link>
              <button className="w-full px-4 py-2 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors border border-white/20">
                System Logs
              </button>
              <button className="w-full px-4 py-2 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors border border-white/20">
                Error Logs
              </button>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Emergency Actions
            </h3>
            <div className="space-y-3">
              <button className="w-full px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors">
                Lockdown All Doors
              </button>
              <button className="w-full px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 transition-colors">
                Emergency Override
              </button>
              <button className="w-full px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors">
                System Restart
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
