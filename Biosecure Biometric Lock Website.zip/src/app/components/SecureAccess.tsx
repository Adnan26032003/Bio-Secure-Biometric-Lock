import { useState } from 'react';
import { Link } from 'react-router';
import { Shield, Lock, Unlock, DoorOpen, DoorClosed, MapPin, Activity, AlertTriangle, ArrowLeft } from 'lucide-react';

export default function SecureAccess() {
  const [doors, setDoors] = useState([
    { id: 1, name: 'Main Entrance - Door A', location: 'Building A - Floor 1', status: 'locked', lastAccess: '2 min ago', activity: 'high' },
    { id: 2, name: 'Conference Room - Door B', location: 'Building A - Floor 2', status: 'unlocked', lastAccess: '5 min ago', activity: 'medium' },
    { id: 3, name: 'Server Room - Door C', location: 'Building B - Floor 1', status: 'locked', lastAccess: '1 hour ago', activity: 'low' },
    { id: 4, name: 'Storage - Door D', location: 'Building A - Floor 3', status: 'locked', lastAccess: '30 min ago', activity: 'low' },
    { id: 5, name: 'Lab - Door E', location: 'Building B - Floor 2', status: 'unlocked', lastAccess: '10 min ago', activity: 'high' },
    { id: 6, name: 'Emergency Exit - Door F', location: 'Building A - Floor 1', status: 'locked', lastAccess: '3 hours ago', activity: 'low' },
  ]);

  const toggleDoorLock = (doorId: number) => {
    setDoors(doors.map(door =>
      door.id === doorId
        ? { ...door, status: door.status === 'locked' ? 'unlocked' : 'locked' }
        : door
    ));
  };

  const lockAllDoors = () => {
    setDoors(doors.map(door => ({ ...door, status: 'locked' })));
  };

  const unlockAllDoors = () => {
    setDoors(doors.map(door => ({ ...door, status: 'unlocked' })));
  };

  const lockedCount = doors.filter(d => d.status === 'locked').length;
  const unlockedCount = doors.filter(d => d.status === 'unlocked').length;
  const highActivityCount = doors.filter(d => d.activity === 'high').length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900">
      <nav className="bg-black/20 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Shield className="w-8 h-8 text-blue-300" />
              <span className="text-2xl font-bold text-white">Secure Access Control</span>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/admin" className="px-4 py-2 text-white hover:text-blue-300 transition-colors">
                Admin
              </Link>
              <Link to="/access-history" className="px-4 py-2 text-white hover:text-blue-300 transition-colors">
                History
              </Link>
              <Link to="/" className="px-4 py-2 text-white hover:text-blue-300 transition-colors flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Home
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-2">
            <Lock className="w-8 h-8" />
            Secure Access Management
          </h1>
          <p className="text-blue-200">Control and monitor all biometric door locks in real-time</p>
        </div>

        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 rounded-lg bg-blue-500/20">
                <DoorClosed className="w-6 h-6 text-blue-300" />
              </div>
            </div>
            <div className="text-3xl font-bold text-white mb-1">{doors.length}</div>
            <div className="text-blue-200 text-sm">Total Doors</div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 rounded-lg bg-green-500/20">
                <Lock className="w-6 h-6 text-green-300" />
              </div>
            </div>
            <div className="text-3xl font-bold text-green-300 mb-1">{lockedCount}</div>
            <div className="text-blue-200 text-sm">Locked</div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 rounded-lg bg-yellow-500/20">
                <Unlock className="w-6 h-6 text-yellow-300" />
              </div>
            </div>
            <div className="text-3xl font-bold text-yellow-300 mb-1">{unlockedCount}</div>
            <div className="text-blue-200 text-sm">Unlocked</div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 rounded-lg bg-red-500/20">
                <Activity className="w-6 h-6 text-red-300" />
              </div>
            </div>
            <div className="text-3xl font-bold text-red-300 mb-1">{highActivityCount}</div>
            <div className="text-blue-200 text-sm">High Activity</div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20 mb-8">
          <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
          <div className="flex flex-wrap gap-4">
            <button
              onClick={lockAllDoors}
              className="flex items-center gap-2 px-6 py-3 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors font-semibold"
            >
              <Lock className="w-5 h-5" />
              Lock All Doors
            </button>
            <button
              onClick={unlockAllDoors}
              className="flex items-center gap-2 px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors font-semibold"
            >
              <Unlock className="w-5 h-5" />
              Unlock All Doors
            </button>
            <button className="flex items-center gap-2 px-6 py-3 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 transition-colors font-semibold">
              <AlertTriangle className="w-5 h-5" />
              Emergency Override
            </button>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 overflow-hidden">
          <div className="p-6 border-b border-white/20">
            <h2 className="text-xl font-semibold text-white flex items-center gap-2">
              <DoorOpen className="w-5 h-5" />
              Door Status & Control
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
            {doors.map((door) => (
              <div key={door.id} className="bg-white/5 backdrop-blur-sm rounded-lg p-6 border border-white/10 hover:bg-white/10 transition-all">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    {door.status === 'locked' ? (
                      <div className="p-2 rounded-lg bg-green-500/20">
                        <Lock className="w-6 h-6 text-green-300" />
                      </div>
                    ) : (
                      <div className="p-2 rounded-lg bg-yellow-500/20">
                        <Unlock className="w-6 h-6 text-yellow-300" />
                      </div>
                    )}
                    <div>
                      <h3 className="font-semibold text-white">{door.name}</h3>
                      <span
                        className={`inline-block mt-1 px-2 py-1 rounded-full text-xs font-semibold ${
                          door.status === 'locked'
                            ? 'bg-green-500/20 text-green-300'
                            : 'bg-yellow-500/20 text-yellow-300'
                        }`}
                      >
                        {door.status === 'locked' ? 'Secured' : 'Open'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm text-blue-200">
                    <MapPin className="w-4 h-4" />
                    {door.location}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-blue-200">
                    <Activity className="w-4 h-4" />
                    Last access: {door.lastAccess}
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-blue-200">Activity:</span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                        door.activity === 'high'
                          ? 'bg-red-500/20 text-red-300'
                          : door.activity === 'medium'
                          ? 'bg-yellow-500/20 text-yellow-300'
                          : 'bg-green-500/20 text-green-300'
                      }`}
                    >
                      {door.activity}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => toggleDoorLock(door.id)}
                  className={`w-full py-2 rounded-lg font-semibold transition-colors ${
                    door.status === 'locked'
                      ? 'bg-yellow-500 hover:bg-yellow-600 text-white'
                      : 'bg-green-500 hover:bg-green-600 text-white'
                  }`}
                >
                  {door.status === 'locked' ? 'Unlock Door' : 'Lock Door'}
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
