import { Shield, Lock, Fingerprint, History, UserPlus, LogIn } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900">
      <nav className="bg-black/20 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Shield className="w-8 h-8 text-blue-300" />
              <span className="text-2xl font-bold text-white">BioSecure</span>
            </div>
            <div className="flex gap-4">
              <a href="/login" className="px-4 py-2 text-white hover:text-blue-300 transition-colors">
                Login
              </a>
              <a href="/register" className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                Register
              </a>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <div className="p-4 bg-blue-500/20 rounded-full backdrop-blur-sm">
              <Fingerprint className="w-24 h-24 text-blue-300" />
            </div>
          </div>
          <h1 className="text-5xl font-bold text-white mb-4">
            BioSecure Biometric Lock System
          </h1>
          <p className="text-xl text-blue-200 max-w-2xl mx-auto">
            Advanced biometric authentication for maximum security. Protect what matters most with cutting-edge fingerprint technology.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <a href="/secure-access" className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20 hover:bg-white/15 transition-all cursor-pointer">
            <div className="flex justify-center mb-4">
              <Lock className="w-12 h-12 text-blue-300" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2 text-center">Secure Access</h3>
            <p className="text-blue-200 text-center">
              State-of-the-art biometric authentication ensures only authorized users can access protected areas.
            </p>
          </a>

          <a href="/access-history" className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20 hover:bg-white/15 transition-all cursor-pointer">
            <div className="flex justify-center mb-4">
              <History className="w-12 h-12 text-blue-300" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2 text-center">Access History</h3>
            <p className="text-blue-200 text-center">
              Track all access attempts with detailed logs and real-time monitoring capabilities.
            </p>
          </a>

          <a href="/admin-control" className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20 hover:bg-white/15 transition-all cursor-pointer">
            <div className="flex justify-center mb-4">
              <Shield className="w-12 h-12 text-blue-300" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2 text-center">Admin Control</h3>
            <p className="text-blue-200 text-center">
              Comprehensive admin dashboard for managing users, permissions, and security settings.
            </p>
          </a>
        </div>

        <div className="flex justify-center gap-6">
          <a
            href="/register"
            className="flex items-center gap-2 px-8 py-4 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-lg font-semibold"
          >
            <UserPlus className="w-5 h-5" />
            Get Started
          </a>
          <a
            href="/login"
            className="flex items-center gap-2 px-8 py-4 bg-white/10 backdrop-blur-sm text-white rounded-lg hover:bg-white/20 transition-colors text-lg font-semibold border border-white/20"
          >
            <LogIn className="w-5 h-5" />
            Sign In
          </a>
        </div>
      </div>

      <footer className="bg-black/20 backdrop-blur-sm border-t border-white/10 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center text-blue-200">
          <p>&copy; 2024 BioSecure. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
