import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { Shield, Fingerprint, Mail, Lock, Eye, EyeOff } from 'lucide-react';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [biometricAuth, setBiometricAuth] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock authentication - in real app, verify credentials
    if (email === 'admin@biosecure.com' && password === 'admin123') {
      navigate('/admin');
    } else {
      alert('Invalid credentials. Try admin@biosecure.com / admin123');
    }
  };

  const handleBiometricAuth = () => {
    setBiometricAuth(true);
    // Simulate biometric scan
    setTimeout(() => {
      alert('Biometric authentication successful!');
      navigate('/admin');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <Shield className="w-10 h-10 text-blue-300" />
            <span className="text-3xl font-bold text-white">BioSecure</span>
          </Link>
          <h2 className="text-2xl font-bold text-white">Sign in to your account</h2>
          <p className="text-blue-200 mt-2">Access the biometric lock system</p>
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20">
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-white mb-2">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/20 rounded-lg text-white placeholder-blue-300/50 focus:outline-none focus:border-blue-400"
                  placeholder="Enter your email"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-white mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-12 py-3 bg-white/5 border border-white/20 rounded-lg text-white placeholder-blue-300/50 focus:outline-none focus:border-blue-400"
                  placeholder="Enter your password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-blue-300 hover:text-blue-200"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-semibold"
            >
              Sign In
            </button>
          </form>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-white/20"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-4 bg-transparent text-blue-200">Or continue with</span>
            </div>
          </div>

          <button
            onClick={handleBiometricAuth}
            disabled={biometricAuth}
            className="w-full py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors font-semibold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Fingerprint className={`w-5 h-5 ${biometricAuth ? 'animate-pulse' : ''}`} />
            {biometricAuth ? 'Scanning fingerprint...' : 'Biometric Authentication'}
          </button>

          <div className="mt-6 text-center space-y-2">
            <p className="text-blue-200">
              Don't have an account?{' '}
              <Link to="/register" className="text-blue-300 hover:text-blue-200 font-semibold">
                Register here
              </Link>
            </p>
            <Link to="/" className="text-blue-300 hover:text-blue-200 text-sm block">
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
